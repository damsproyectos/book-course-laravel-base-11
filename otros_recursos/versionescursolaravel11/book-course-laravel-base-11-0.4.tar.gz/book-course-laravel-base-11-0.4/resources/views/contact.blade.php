@extends('master')

@section('contect')
    <h1>Contact</h1>   
    {{$name}}
@endsection