@extends('master')

@section('contect')
    <h1>Contact 2</h1>
   
@endsection